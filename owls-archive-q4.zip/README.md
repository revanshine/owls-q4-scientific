# OWLS Archive Q4 — Four-Quadrant Operators & Pipeline

See TASKS.md for instructions.
