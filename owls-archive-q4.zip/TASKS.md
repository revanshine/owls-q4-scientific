
# Tasks for Code Assistant (Q/Codex)

- Build Terraform per design brief (S3/SQS/Lambda/SFN).
- Package Lambda to run `q4.cli` on chunked input, emit MANIFEST + er.json.
- Add FITS loader and time-series flattening; add KS/corr gates in tests.
